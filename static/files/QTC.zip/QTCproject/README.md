------------------------- Secure Module/Key Management Application -----------------------------

Overview:
The Secure Module/Key Management Application is designed to facilitate secure data transfer between 
servers across various domains. Utilizing HTTPS for data transfer, it focuses on encrypting logged HTTP activity, 
ensuring data integrity and confidentiality.

---------------------------- Technical Design -----------------------------------

Microservices Architecture: Modular design for easy maintenance and scalability.
Azure Key Vault: Secure storage and management of secrets, keys, and certificates.
Microsoft SQL Server: Reliable database management system for data storage.
ASP.NET Core:  Utilized alongside SQL Server and Azure Key Vault for robust application development.

---------------------------- Use Cases ----------------------------------------------

1.Secure Data Transfer Within Trusted Domain: Ensures safe and encrypted communication internally.
2.Transmission Between Trusted and Untrusted Domains: Extends secure communication capabilities with 
external domains, maintaining encryption standards.
3.Key Encryption Methods: Incorporating AES and RSA encryption for secure data handling.

------------------------- Setup and Configuration -----------------------------------------

Azure Key Vault Setup: Steps to configure Azure Key Vault for storing application secrets.
OpenSSL Integration: Guide on integrating OpenSSL for encryption and decryption processes.

------------------------- Contribution Guidelines ----------------------------------------

Submitting Pull Requests: Guidelines on how to submit pull requests for code review.
Code Reviews: Importance and process of reviewing code for maintaining quality.

---------------------------- Branching Strategy -------------------------------------------

Detailed explanation of branching strategy, including roles of branches like sql-server, 
frontend, and azure-key-vault to their specfiied roles.

----------------------------- Stakeholders --------------------------------------------

List of key stakeholders and their roles in the project development

----------------------------- References -----------------------------------------------

Links to external documents and resources crucial for understanding the project's technical aspects

------------------------------- Appendix ------------------------------------------------

Additional resources and detailed explanations of specific components of the application.
default credentials for proof of concept login page: admin@admin.com / admin
