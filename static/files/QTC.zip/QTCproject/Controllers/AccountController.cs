using Microsoft.AspNetCore.Mvc;

namespace QTCProject.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account/Login

        //make login button go to InputData page
        public IActionResult Login(string email, string password)
        {
            if (email == "admin@admin.com" && password == "admin")
            {
                return RedirectToAction("InputData", "Patients");
            }
            else
            {
                return View("~/Views/Login Page/LoginPage.cshtml");
            }
        }

        // GET: Account/Logout
        public IActionResult Logout()
        {
            return View("~/Views/Login Page/LoginPage.cshtml");
        }
    }
}
